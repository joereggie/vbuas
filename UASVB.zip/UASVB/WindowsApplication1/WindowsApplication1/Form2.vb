﻿Public Class UTAMA

    Private Sub UTAMA_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Enabled = False
        Me.Visible = False
        LOGIN.Show()
    End Sub
End Class